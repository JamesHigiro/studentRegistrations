
package Iimplementation;

import DAo.GeneralDao;
import RemoteInterfaces.IFaculty;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import model.Faculty;

/**
 *
 * @author NGABO
 */
public class FacultyService extends UnicastRemoteObject implements IFaculty{
    GeneralDao<Faculty> dao  = new GeneralDao<>(Faculty.class);

    public FacultyService() throws RemoteException {
        super();
    }
    
    

    @Override
    public void save(Faculty fac) throws RemoteException {
        Faculty f = new Faculty();
        dao.create(f);
        
       
    }
    
}
