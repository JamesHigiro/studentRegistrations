/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Iimplementation;

import DAo.GeneralDao;
import RemoteInterfaces.IStudent;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import model.Student;

/**
 *
 * @author NGABO
 */
public class StudentService extends UnicastRemoteObject implements IStudent{
    GeneralDao<Student> dao = new GeneralDao<>(Student.class);

    public StudentService() throws RemoteException {
        super();
    }
    

    @Override
    public void save(Student st) throws RemoteException {
        Student stu = new Student();
        dao.create(stu);
        
        
    }
    
}
