
package RemoteInterfaces;

import java.rmi.*;
import model.Faculty;

/**
 *
 * @author NGABO
 */
public interface IFaculty extends Remote{
    // create methods
    public void save(Faculty fac) throws RemoteException;
 }
