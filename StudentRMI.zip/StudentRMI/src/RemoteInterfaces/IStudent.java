/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RemoteInterfaces;

import java.rmi.*;
import model.Student;

/**
 *
 * @author NGABO
 */
public interface IStudent extends Remote{
    public void save(Student st) throws RemoteException;
    
}
